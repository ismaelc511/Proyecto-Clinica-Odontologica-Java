package com.example.ProyectoFinal.model;

public enum UsuarioRol {
    USER, ADMIN
}
